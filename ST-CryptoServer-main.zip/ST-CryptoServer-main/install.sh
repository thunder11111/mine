wget https://github.com/C3Pool/ST-CryptoServer/releases/download/v1.0.5/StarMap-CryptoTool.tar.gz
tar -zxvf StarMap-CryptoTool.tar.gz
bash start.sh